﻿
namespace Server.MTv2.Messaging
{
    public class Person
    {
        //fields
        private string name;

        //constructors
        public Person(string name)
        {
            this.name = name;
        }

        //properties
        public string Name
        {
            get
            {
                return name;
            }
        }
    }
}
